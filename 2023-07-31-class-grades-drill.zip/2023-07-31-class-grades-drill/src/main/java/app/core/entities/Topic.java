package app.core.entities;

public enum Topic {
	MATH, GEOGRAPHY, LITERATURE
}
